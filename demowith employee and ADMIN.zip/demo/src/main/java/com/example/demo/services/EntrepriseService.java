package com.example.demo.services;

import com.example.demo.repository.EntrepriseRepository;
import com.example.demo.repository.ClientRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class EntrepriseService {
    @Autowired
    private  EntrepriseRepository entrepriseRepository;
    @Autowired
    private  ClientRepository clientRepository;

    
    

    
}
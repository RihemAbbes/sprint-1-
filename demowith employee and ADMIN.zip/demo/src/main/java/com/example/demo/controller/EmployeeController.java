package com.example.demo.controller;

import com.example.demo.entities.Employee;
import com.example.demo.services.EmployeeService;
import com.example.demo.services.EmployeeService.ClientDetailsDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/employee")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    // get emplyee's list 
    @GetMapping
    public List<Employee> getAllEmployees() {
        return employeeService.getAllEmployees();
    }

    // get employee  by  ID
    @GetMapping("/{id}")
    public Employee getEmployeeById(@PathVariable Long id) {
        return employeeService.getEmployeeById(id);
    }

    // get client matched form and enterprise 
    @GetMapping("/{id}/clients-details")
    public List<ClientDetailsDTO> getAssignedClientsWithForms(@PathVariable Long id) {
        return employeeService.getAssignedClientsWithForms(id);
    }
}

package com.example.demo.services;

import com.example.demo.entities.Admin;
import com.example.demo.entities.Employee;
import com.example.demo.entities.Client;
import com.example.demo.entities.Form;
import com.example.demo.entities.Statut;
import com.example.demo.repository.AdminRepository;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.repository.ClientRepository;
import com.example.demo.repository.FormRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class AdminService {
    
    @Autowired
    private AdminRepository adminRepository;
    
    @Autowired
    private EmployeeRepository employeeRepository;
    
    @Autowired
    private ClientRepository clientRepository;
    
    @Autowired
    private FormRepository formRepository;

    // Add employee
    public Employee addEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    // update employee
    public Employee updateEmployee(Long id, Employee employeeDetails) {
        Optional<Employee> optionalEmployee = employeeRepository.findById(id);
        if (optionalEmployee.isPresent()) {
            Employee employee = optionalEmployee.get();
            employee.setNom(employeeDetails.getNom());
            employee.setPrenom(employeeDetails.getPrenom());
            employee.setEmail(employeeDetails.getEmail());
            employee.setPoste(employeeDetails.getPoste());
            return employeeRepository.save(employee);
        }
        throw new RuntimeException("Employé non trouvé avec l'ID: " + id);
    }

    // See employees list 
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    // ensure communication 
    public String assignClientToEmployee(Long employeeId, Long clientId) {
        Optional<Employee> optionalEmployee = employeeRepository.findById(employeeId);
        Optional<Client> optionalClient = clientRepository.findById(clientId);
        Optional<Form> optionalForm = formRepository.findById(clientId);

        if (optionalEmployee.isPresent() && optionalClient.isPresent() && optionalForm.isPresent()) {
            Form form = optionalForm.get();
            if (form.getStatut() != Statut.VALIDE) {
                return "Le client " + optionalClient.get().getNom() + " a été rejeté et ne peut pas être assigné à un employé.";
            }

            Employee employee = optionalEmployee.get();
            Client client = optionalClient.get();
            List<Client> clients = employee.getAssignedClients();
            if (clients == null) {
            	clients = new ArrayList<>();
            }
            clients.add(client);
            employee.setAssignedClients(clients);
            employeeRepository.save(employee);
            return "Le client " + client.getNom() + " a été assigné à l'employé " + employee.getNom();
        }
        throw new RuntimeException("Employé, Client ou Formulaire non trouvé");
    }
}

package com.example.demo.services;

import com.example.demo.entities.Client;
import com.example.demo.entities.Employee;
import com.example.demo.entities.Form;
import com.example.demo.entities.Entreprise;
import com.example.demo.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    // get employee's list 
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    // get employee by  ID
    public Employee getEmployeeById(Long id) {
        Optional<Employee> employee = employeeRepository.findById(id);
        return employee.orElseThrow(() -> new RuntimeException("Employé non trouvé avec ID: " + id));
    }

    // get clients assigned to an employee by their forms 
    public List<ClientDetailsDTO> getAssignedClientsWithForms(Long employeeId) {
        Employee employee = getEmployeeById(employeeId);
        List<Client> clients = employee.getAssignedClients();

        return clients.stream().map(client -> new ClientDetailsDTO(
                client,
                client.getForms(),  // filed forms by client
                client.getEntreprise()  // the enterprise that send the  client (if found )
        )).collect(Collectors.toList());
    }

    // DTO to structure data sent to the front-end
    public static class ClientDetailsDTO {
        private Client client;
        private List<Form> forms;
        private Entreprise entreprise;

        public ClientDetailsDTO(Client client, List<Form> forms, Entreprise entreprise) {
            this.client = client;
            this.forms = forms;
            this.entreprise = entreprise;
        }

        public Client getClient() { return client; }
        public List<Form> getForms() { return forms; }
        public Entreprise getEntreprise() { return entreprise; }
    }
}

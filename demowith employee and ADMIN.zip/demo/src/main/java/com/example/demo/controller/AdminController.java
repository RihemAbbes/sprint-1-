package com.example.demo.controller;

import com.example.demo.entities.Employee;
import com.example.demo.services.AdminService;
import lombok.AllArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200") // Permet l'accès depuis Angular
@RequestMapping("/admin")
@AllArgsConstructor
public class AdminController {

	@Autowired
    private  AdminService adminService;

    // Add employee
    @PostMapping("/employees")
    public Employee addEmployee(@RequestBody Employee employee) {
        return adminService.addEmployee(employee);
    }

    // Modifier employee
    @PutMapping("/employees/{id}")
    public Employee updateEmployee(@PathVariable Long id, @RequestBody Employee employeeDetails) {
        return adminService.updateEmployee(id, employeeDetails);
    }

    // See employee's List
    @GetMapping("/employees")
    public List<Employee> getAllEmployees() {
        return adminService.getAllEmployees();
    }

    // Assign  client to an  employee after form validation 
    @PostMapping("/assign/{employeeId}/{clientId}")
    public String assignClientToEmployee(@PathVariable Long employeeId, @PathVariable Long clientId) {
        return adminService.assignClientToEmployee(employeeId, clientId);
    }
}
